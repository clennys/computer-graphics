#ifndef CUBE_H
#define CUBE_H

#include "Shape.h"

namespace cgCourse
{
	class Cube : public Shape
	{
	public:
		Cube();
		void draw();
	};
}

#endif //  CUBE_H
